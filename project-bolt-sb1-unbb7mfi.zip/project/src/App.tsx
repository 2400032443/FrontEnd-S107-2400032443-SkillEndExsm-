import { useState } from 'react';
import { LoginForm } from './components/LoginForm';
import { RegistrationForm } from './components/RegistrationForm';
import { GraduationCap } from 'lucide-react';

function App() {
  const [activeForm, setActiveForm] = useState<'login' | 'register'>('login');

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-gray-50 to-green-50 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <GraduationCap className="w-16 h-16 text-blue-600" />
          </div>
          <h1 className="text-4xl font-bold text-gray-800 mb-2">
            Student Portal
          </h1>
          <p className="text-gray-600">
            Access your academic journey
          </p>
        </div>

        <div className="flex justify-center gap-4 mb-8">
          <button
            onClick={() => setActiveForm('login')}
            className={`px-6 py-3 rounded-lg font-medium transition ${
              activeForm === 'login'
                ? 'bg-blue-600 text-white shadow-lg'
                : 'bg-white text-gray-700 hover:bg-gray-100'
            }`}
          >
            Login
          </button>
          <button
            onClick={() => setActiveForm('register')}
            className={`px-6 py-3 rounded-lg font-medium transition ${
              activeForm === 'register'
                ? 'bg-green-600 text-white shadow-lg'
                : 'bg-white text-gray-700 hover:bg-gray-100'
            }`}
          >
            Register
          </button>
        </div>

        <div className="flex justify-center">
          {activeForm === 'login' ? <LoginForm /> : <RegistrationForm />}
        </div>

        <div className="mt-8 text-center text-sm text-gray-600">
          <p>Check the browser console to see form input and submission logs</p>
        </div>
      </div>
    </div>
  );
}

export default App;
