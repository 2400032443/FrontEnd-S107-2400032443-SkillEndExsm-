import { useForm } from '../hooks/useForm';
import { UserPlus } from 'lucide-react';

interface RegistrationFormValues {
  fullName: string;
  email: string;
  studentId: string;
  password: string;
  confirmPassword: string;
}

export function RegistrationForm() {
  const initialValues: RegistrationFormValues = {
    fullName: '',
    email: '',
    studentId: '',
    password: '',
    confirmPassword: '',
  };

  const validate = (values: RegistrationFormValues) => {
    const errors: Partial<Record<keyof RegistrationFormValues, string>> = {};

    if (!values.fullName) {
      errors.fullName = 'Full name is required';
    } else if (values.fullName.length < 3) {
      errors.fullName = 'Name must be at least 3 characters';
    }

    if (!values.email) {
      errors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email)) {
      errors.email = 'Invalid email format';
    }

    if (!values.studentId) {
      errors.studentId = 'Student ID is required';
    } else if (!/^\d+$/.test(values.studentId)) {
      errors.studentId = 'Student ID must contain only numbers';
    }

    if (!values.password) {
      errors.password = 'Password is required';
    } else if (values.password.length < 8) {
      errors.password = 'Password must be at least 8 characters';
    }

    if (!values.confirmPassword) {
      errors.confirmPassword = 'Please confirm your password';
    } else if (values.password !== values.confirmPassword) {
      errors.confirmPassword = 'Passwords do not match';
    }

    return errors;
  };

  const handleRegistration = (values: RegistrationFormValues) => {
    console.log('=== REGISTRATION FORM SUBMITTED ===');
    console.log('Full Name:', values.fullName);
    console.log('Email:', values.email);
    console.log('Student ID:', values.studentId);
    console.log('Password:', values.password);
    console.log('===================================');
    alert(`Registration successful! Welcome ${values.fullName}!`);
  };

  const { values, errors, handleChange, handleSubmit, resetForm } = useForm(
    initialValues,
    handleRegistration,
    validate
  );

  return (
    <div className="w-full max-w-md bg-white rounded-lg shadow-lg p-8">
      <div className="flex items-center justify-center mb-6">
        <UserPlus className="w-8 h-8 text-green-600 mr-2" />
        <h2 className="text-2xl font-bold text-gray-800">Student Registration</h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="reg-fullName" className="block text-sm font-medium text-gray-700 mb-1">
            Full Name
          </label>
          <input
            type="text"
            id="reg-fullName"
            name="fullName"
            value={values.fullName}
            onChange={handleChange}
            className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition ${
              errors.fullName ? 'border-red-500' : 'border-gray-300'
            }`}
            placeholder="John Doe"
          />
          {errors.fullName && (
            <p className="mt-1 text-sm text-red-600">{errors.fullName}</p>
          )}
        </div>

        <div>
          <label htmlFor="reg-email" className="block text-sm font-medium text-gray-700 mb-1">
            Email Address
          </label>
          <input
            type="email"
            id="reg-email"
            name="email"
            value={values.email}
            onChange={handleChange}
            className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition ${
              errors.email ? 'border-red-500' : 'border-gray-300'
            }`}
            placeholder="student@university.edu"
          />
          {errors.email && (
            <p className="mt-1 text-sm text-red-600">{errors.email}</p>
          )}
        </div>

        <div>
          <label htmlFor="reg-studentId" className="block text-sm font-medium text-gray-700 mb-1">
            Student ID
          </label>
          <input
            type="text"
            id="reg-studentId"
            name="studentId"
            value={values.studentId}
            onChange={handleChange}
            className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition ${
              errors.studentId ? 'border-red-500' : 'border-gray-300'
            }`}
            placeholder="12345678"
          />
          {errors.studentId && (
            <p className="mt-1 text-sm text-red-600">{errors.studentId}</p>
          )}
        </div>

        <div>
          <label htmlFor="reg-password" className="block text-sm font-medium text-gray-700 mb-1">
            Password
          </label>
          <input
            type="password"
            id="reg-password"
            name="password"
            value={values.password}
            onChange={handleChange}
            className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition ${
              errors.password ? 'border-red-500' : 'border-gray-300'
            }`}
            placeholder="Enter your password"
          />
          {errors.password && (
            <p className="mt-1 text-sm text-red-600">{errors.password}</p>
          )}
        </div>

        <div>
          <label htmlFor="reg-confirmPassword" className="block text-sm font-medium text-gray-700 mb-1">
            Confirm Password
          </label>
          <input
            type="password"
            id="reg-confirmPassword"
            name="confirmPassword"
            value={values.confirmPassword}
            onChange={handleChange}
            className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition ${
              errors.confirmPassword ? 'border-red-500' : 'border-gray-300'
            }`}
            placeholder="Confirm your password"
          />
          {errors.confirmPassword && (
            <p className="mt-1 text-sm text-red-600">{errors.confirmPassword}</p>
          )}
        </div>

        <div className="flex gap-3 pt-2">
          <button
            type="submit"
            className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition font-medium"
          >
            Register
          </button>
          <button
            type="button"
            onClick={resetForm}
            className="flex-1 bg-gray-200 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-300 transition font-medium"
          >
            Clear
          </button>
        </div>
      </form>
    </div>
  );
}
