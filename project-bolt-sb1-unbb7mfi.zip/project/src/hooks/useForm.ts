import { useState, ChangeEvent, FormEvent } from 'react';

interface UseFormReturn<T> {
  values: T;
  errors: Partial<Record<keyof T, string>>;
  handleChange: (e: ChangeEvent<HTMLInputElement>) => void;
  handleSubmit: (e: FormEvent<HTMLFormElement>) => void;
  resetForm: () => void;
  setFieldError: (field: keyof T, error: string) => void;
}

export function useForm<T extends Record<string, string>>(
  initialValues: T,
  onSubmit: (values: T) => void,
  validate?: (values: T) => Partial<Record<keyof T, string>>
): UseFormReturn<T> {
  const [values, setValues] = useState<T>(initialValues);
  const [errors, setErrors] = useState<Partial<Record<keyof T, string>>>({});

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    console.log(`Input changed - Field: ${name}, Value: ${value}`);

    setValues((prev) => ({
      ...prev,
      [name]: value,
    }));

    if (errors[name as keyof T]) {
      setErrors((prev) => ({
        ...prev,
        [name]: '',
      }));
    }
  };

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    console.log('Form submission initiated');
    console.log('Current form values:', values);

    if (validate) {
      const validationErrors = validate(values);
      console.log('Validation errors:', validationErrors);

      if (Object.keys(validationErrors).length > 0) {
        setErrors(validationErrors);
        console.log('Form submission blocked due to validation errors');
        return;
      }
    }

    console.log('Form submitted successfully with values:', values);
    onSubmit(values);
  };

  const resetForm = () => {
    console.log('Form reset');
    setValues(initialValues);
    setErrors({});
  };

  const setFieldError = (field: keyof T, error: string) => {
    setErrors((prev) => ({
      ...prev,
      [field]: error,
    }));
  };

  return {
    values,
    errors,
    handleChange,
    handleSubmit,
    resetForm,
    setFieldError,
  };
}
